<?php 
    require 'koneksi.php';
    
    if(isset($_POST['hasil'])){
        if($kode=""){
            echo "Kode Barang belum dimasukan";
        }elseif($nama=""){
            echo "Nama Barang belum dimasukan";
        }elseif($merek=""){
            echo "Merek Barang belum dimasukan";
        }elseif($jumlah=""){
            echo "Jumlah Barang belum dimasukan";
        }elseif($harga=""){
            echo "Harga Barang belum dimasukan";
        }else{
            $id = $_POST['id'];
            $kode = $_POST['kode'];
            $nama = $_POST['nama'];
            $merek = $_POST['merek'];
            $jumlah = $_POST['jumlah'];
            $harga = $_POST['harga'];
            $submit = $_POST['hasil'];
            
            $query = "INSERT INTO barang(id,kode_barang,nama_barang,merek,jumlah,harga) VALUES ('$id','$kode','$nama','$merek','$jumlah','$harga')";
            mysqli_query($conn, $query);
            echo "
                <script>
                    alert('Anda sudah menambahkan data');
                    document.location.href = 'barang_masuk.php'
                </script>
            ";
        }
        
    }
?>