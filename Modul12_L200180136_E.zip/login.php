<?php 
    require 'koneksi.php';
    session_start();
    error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);

    $username = $_POST['username'];
    $password = $_POST['password'];
    $submit = $_POST['submit'];


    if($submit){
        $sql = "select * from user where username='$username' and password='$password'";
        $query = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['username']!=""){
            $_SESSION['username']=$row['username'];
            $_SESSION['status']=$row['status'];
            header("Location: index.php"); 
        }
    }           
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <link href="css/sb-admin-2.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

    <title>Login</title>
</head>
    <body class="bg-gradient-primary">
        <center>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-4">
                            <div class="form-login my-5">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Selamat Datang di BigMart</h1>
                                </div>
                                <form class="user" method="POST" action="login.php">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user"
                                            name="username" placeholder="Enter username...">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user"
                                            name="password" placeholder="Password">
                                    </div>
                                    <input type="submit" name="submit" id="submit">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </center>
</body>
</html>