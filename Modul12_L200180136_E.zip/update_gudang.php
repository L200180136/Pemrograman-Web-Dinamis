<?php
    require 'koneksi.php';
    session_start();
    error_reporting(E_ALL^E_NOTICE);

    $id = $_POST['id'];
    $kode = $_POST['kode'];
    $nama = $_POST['nama'];
    $merek = $_POST['merek'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $tglm = $_POST['tgl_masuk'];
    $tglk = $_POST['tgl_keluar'];
    $submit = $_POST['hasil'];

    $query = "UPDATE gudang SET kode_barangfk = '$kode', nama_barang = '$nama', merek = '$merek', jumlah = '$jumlah',  harga = '$harga', tgl_masuk = '$tglm', tgl_keluar = '$tglk'  WHERE id = '$id'";


    if ($submit) {
        if ($kode=''){
            echo "Kode Barang tidak boleh kosong";
        }elseif($nama=''){
            echo "Nama Barang tidak boleh kosong";
        }elseif ($merek=''){
			echo "Merek Barang tidak boleh kosong";
		}elseif ($jumlah=''){
			echo "Jumlah Barang tidak boleh kosong";
		}elseif ($harga=''){
			echo "Harga Barang tidak boleh kosong";
		}elseif ($tglm=''){
			echo "Tanggal Masuk Barang tidak boleh kosong";
		}elseif ($tglk=''){
			echo "Tanggal Keluar Barang tidak boleh kosong";
		}else
			mysqli_query($conn,$query);
			echo "
                <script>
                    alert('Data berhasil di update');
				    document.location.href='barang_keluar.php';
				</script>
			";
		}
        
    
?>
