<?php
    session_start();
    $conn = mysqli_connect('localhost', 'id15801339_root', 'VGn+69F]66@xVEEQ', 'id15801339_db_kasir');
    error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
?>