<?php
    require 'koneksi.php';
    session_start();
    error_reporting(E_ALL^E_NOTICE);

    $id = $_POST['id'];
    $kode = $_POST['kode'];
    $nama = $_POST['nama'];
    $merek = $_POST['merek'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $submit = $_POST['hasil'];

    $query = "UPDATE barang SET kode_barang = '$kode', nama_barang = '$nama', merek = '$merek', jumlah = '$jumlah',  harga = '$harga' WHERE id = '$id'"; 

    if ($submit) {
        if ($id=''){
            echo "ID Barang tidak boleh kosong";
        }elseif($kode=''){
            echo "Kode Barang tidak boleh kosong";
        }elseif ($nama=''){
			echo "Nama Barang tidak boleh kosong";
		}elseif ($merek=''){
			echo "Merek Barang tidak boleh kosong";
        }elseif($jumlah=''){
            echo "Jumlah Barang tidak boleh kosong";
        }elseif($harga=''){
            echo "Harga Barang tidak boleh kosong";
        }else
			mysqli_query($conn,$query);
			echo "
                <script>
                    alert('Data berhasil di update');
				    document.location.href='barang_masuk.php';
				</script>
			";
		}
        
    
?>
