<?php
    require "koneksi.php";
    
    $id = $_GET['id'];

    if (isset($id)){
        echo "
            <script>
                alert('Anda sudah menghapus data');
                document.location.href='barang_masuk.php';
            </script> 
        ";
        $result = mysqli_query($conn, "DELETE FROM barang WHERE id=$id");
    }

?>